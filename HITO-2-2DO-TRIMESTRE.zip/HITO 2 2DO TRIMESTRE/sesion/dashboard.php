<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
// Verifica si el usuario está autenticado

if (!isset($_SESSION['id_usuario'])) { // Si no hay un usuario en sesión, lo redirige al login
    header("Location: login.php"); // Redirige a la página de inicio de sesión
    exit(); // Detiene la ejecución del script
}
?>

<!DOCTYPE html>
<html lang="es">
<head>

    <meta charset="UTF-8"> <!-- Configura la codificación de caracteres para soportar acentos y caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Hace la página responsive -->
    <title>Dashboard</title>
    <link rel="stylesheet" href="../ESTILOS/sesion.css"> <!-- Enlace a la hoja de estilos CSS -->

</head>
<body>
    <div class="container">
        <h1>Bienvenido, <?= htmlspecialchars($_SESSION['usuario']); ?></h1>
        <!-- Muestra el nombre del usuario autenticado de forma segura evitando inyección de código -->
        <div class="button-group">
            <!-- Botón para gestionar tareas, redirige a la lista de tareas -->
            <a class="btn tareas-btn" href="../tareas/listar.php">Gestionar Tareas</a>
            <!-- Botón para cerrar sesión con confirmación -->
            <a class="btn logout-btn" href="logout.php" onclick="return confirm('¿Seguro que quieres cerrar sesión?');">Cerrar Sesión</a>
        </div>
    </div>
    
</body>
</html>
