<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
require '../config/conexion.php'; // Incluye el archivo de conexión a la base de datos

$db = new Conexion(); // Crea una instancia de la clase de conexión
$conn = Conexion::$conn; // Obtiene la conexión activa
$mensaje = ''; // Variable para mostrar mensajes de error o éxito

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Verifica si el formulario fue enviado
    $usuario = trim($_POST['usuario']); // Limpia el nombre de usuario
    $correo = trim($_POST['correo']); // Limpia el correo electrónico
    $contrasena = trim($_POST['contrasena']); // Limpia la contraseña

    if (!empty($usuario) && !empty($correo) && !empty($contrasena)) { // Verifica que los campos no estén vacíos
        // Verificar si el correo ya está registrado
        $stmt = $conn->prepare("SELECT id_usuario FROM usuarios WHERE correo_electronico = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) { // Si el correo ya está registrado
            $mensaje = "El correo electrónico ya está registrado.";
        } else {
            // Hashear la contraseña para almacenarla de forma segura
            $hash_contrasena = password_hash($contrasena, PASSWORD_BCRYPT);
            
            // Insertar el nuevo usuario en la base de datos
            $stmt = $conn->prepare("INSERT INTO usuarios (nombre_usuario, correo_electronico, contraseña_hash) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $usuario, $correo, $hash_contrasena);

            if ($stmt->execute()) { // Si la inserción es exitosa
                $mensaje = "Usuario registrado exitosamente.";
            } else { // Si hay un error en la inserción
                $mensaje = "Error al registrar el usuario.";
            }
        }

        $stmt->close();
    } else {
        $mensaje = "Todos los campos son obligatorios."; // Mensaje si hay campos vacíos
    }

    $db->cerrar(); // Cierra la conexión a la base de datos
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> <!-- Configura la codificación de caracteres -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Hace la página responsive -->
    <title>Registro de Usuarios</title>
    <link rel="stylesheet" href="../ESTILOS/sesion.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <div class="container">
        <h1>Registro de Usuarios</h1>

        <!-- Mostrar mensajes de éxito o error -->
        <?php if ($mensaje): ?>
            <p class="<?= strpos($mensaje, 'Usuario registrado exitosamente') !== false ? 'success' : 'error' ?>">
                <?= htmlspecialchars($mensaje) ?>
            </p>
        <?php endif; ?>

        <!-- Formulario de Registro -->
        <form method="POST" action="registro.php">
            <input type="text" name="usuario" placeholder="Nombre de usuario" required>
            <input type="email" name="correo" placeholder="Correo electrónico" required>
            <input type="password" name="contrasena" placeholder="Contraseña" required>
            <button type="submit">Registrarse</button>
        </form>

        <!-- Enlace para iniciar sesión -->
        <a class="register-link" href="login1.php">¿Ya tienes cuenta? Iniciar Sesión</a>
    </div>
</body>
</html>
