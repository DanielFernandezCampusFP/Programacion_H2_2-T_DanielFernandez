<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
require '../config1/conexion.php'; // Se requiere el archivo de conexión a la base de datos

// Conectar a la base de datos
$db = new Conexion(); // Instancia de la clase de conexión
$conn = Conexion::$conn; // Accede a la conexión estática
$mensaje = ''; // Variable para mostrar mensajes de error o éxito

if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Verifica si se envió el formulario
    $correo = trim($_POST['correo']); // Obtiene y limpia el correo ingresado
    $contrasena = trim($_POST['contrasena']); // Obtiene y limpia la contraseña ingresada

    if (!empty($correo) && !empty($contrasena)) { // Verifica que los campos no estén vacíos
        // Consulta preparada para evitar inyección SQL
        $stmt = $conn->prepare("SELECT id_usuario, nombre_usuario, contraseña_hash FROM usuarios WHERE correo_electronico = ?");
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) { // Verifica si el correo existe en la base de datos
            $usuario = $resultado->fetch_assoc();
            // Verifica la contraseña ingresada con la almacenada en la base de datos
            if (password_verify($contrasena, $usuario['contraseña_hash'])) {
                // Inicia sesión y almacena datos del usuario
                $_SESSION['id_usuario'] = $usuario['id_usuario'];
                $_SESSION['usuario'] = $usuario['nombre_usuario'];
                header("Location: dashboard.php"); // Redirige al panel de usuario
                exit();
            } else {
                $mensaje = "Contraseña incorrecta."; // Mensaje de error si la contraseña no coincide
            }
        } else {
            $mensaje = "Correo no registrado."; // Mensaje de error si el correo no existe
        }
        $stmt->close();
    } else {
        $mensaje = "Todos los campos son obligatorios."; // Mensaje de error si hay campos vacíos
    }
    $db->cerrar(); // Cierra la conexión a la base de datos
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> <!-- Configura la codificación de caracteres para soportar caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Hace la página responsive -->
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="../ESTILOS/sesion.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <div class="container">
        <h1>Iniciar Sesión</h1>

        <!-- Muestra mensajes de error o éxito -->
        <?php if ($mensaje): ?>
            <p class="<?= strpos($mensaje, 'Ok') !== false ? 'success' : 'error' ?>">
                <?= htmlspecialchars($mensaje) ?>
            </p>
        <?php endif; ?>

        <!-- Formulario de Inicio de Sesión -->
        <form method="POST" action="login.php">
            <input type="email" name="correo" placeholder="Correo electrónico" required>
            <input type="password" name="contrasena" placeholder="Contraseña" required>
            <button type="submit">Entrar</button>
        </form>

        <!-- Enlace para Registrarse -->
        <a class="register-link" href="registro.php">¿No tienes cuenta? Registrate</a>
    </div>
</body>
</html>
