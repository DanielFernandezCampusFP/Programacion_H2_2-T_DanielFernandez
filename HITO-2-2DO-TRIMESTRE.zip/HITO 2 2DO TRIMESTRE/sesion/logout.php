<?php
session_start(); // Inicia la sesión para poder acceder y manipular sus variables

// Elimina todas las variables de sesión
session_unset();

// Destruye completamente la sesión
session_destroy();

// Redirige al usuario a la página de inicio de sesión
header("Location: login.php");
exit(); // Detiene la ejecución del script para evitar cualquier otro procesamiento
