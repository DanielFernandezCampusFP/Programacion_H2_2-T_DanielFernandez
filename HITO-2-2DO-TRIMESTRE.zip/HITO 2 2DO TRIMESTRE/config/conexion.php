<?php
// Definición de la clase de conexión a la base de datos
class Conexion {
    // Propiedades privadas con los datos de conexión
    private $servidor = '127.0.0.1'; // Dirección del servidor de la base de datos
    private $usuario = 'root'; // Nombre de usuario de la base  de datos
    private $password = 'curso'; // Contraseña de la base de datos
    private $base_datos = 'gestor_tareas'; // Nombre de la base de  datos
    private $puerto = "3307";         // Especifica el puerto correcto

    public static $conn; // Variable estática para almacenar la conexión y reutilizarla
 
    // Constructor: se ejecuta automáticamente cuando se crea una  instancia de la clase
    public function __construct() {
        // Si la conexión aún no ha sido establecida, la crea
        if (!self::$conn) {
            self::$conn = new mysqli($this->servidor, $this->usuario,
$this->password, $this->base_datos);

            // Verifica si la conexión falló
            if (self::$conn->connect_error) {
                die("Error de conexión: " .
self::$conn->connect_error); // Detiene el script si hay un error
             }
        }
    }

    // Método para cerrar la conexión
    public function cerrar() {
         if (self::$conn) {
            self::$conn->close(); // Cierra la conexión con la base de datos
            self::$conn = null; // Restablece la variable de conexión a null
        
        }
    }
}
?>