<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conexion = new mysqli("127.0.0.1", "root", "curso", "gestor_tareas");

if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
} else {
    echo "Conexión exitosa.";
}
?>