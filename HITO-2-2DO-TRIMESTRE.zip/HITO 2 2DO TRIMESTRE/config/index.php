<?php
session_start(); // Inicia la sesión para poder acceder a variables de sesión

// Si el usuario ya ha iniciado sesión, lo redirige directamente al dashboard

if (isset($_SESSION['usuario_id'])) {
    header('Location: ../sesion/dashboard.php'); // Redirecciona a usuario a su panel de control
 exit(); // Termina la ejecución del script para evitar que se siga ejecutando el código
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8"> <!-- Define la codificación de caracteres para soportar tildes y caracteres especiales -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Hace que la página sea responsive -->
    <title>Página de Inicio</title>
    <link rel="stylesheet" href="ESTILOS/index.css"> <!-- Enlace al archivo de estilos CSS específico para esta página -->

</head>
<body>
    <div class="container">
        <h1>Hola</h1>
 
        <div class="button-group">
            <!-- Botón para iniciar sesión, redirige a la página de inicio de sesión -->
             <a class="btn login-btn" href="sesion1/login1.php">Iniciar Sesión</a>
            <!-- Botón para registrarse, redirige a la página de registro -->
             <a class="btn register-btn"
href="sesion1/registro1.php">Registrarse</a>
        </div>
    </div>
</body>
</html>