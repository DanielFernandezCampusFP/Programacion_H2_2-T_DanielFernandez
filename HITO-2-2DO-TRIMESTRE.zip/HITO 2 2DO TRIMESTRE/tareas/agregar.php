<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
require '../config/conexion.php'; // Incluye el archivo de conexión a la base de datos

// Verificar si el usuario está autenticado
if (!isset($_SESSION['id_usuario'])) { // Si el usuario no ha iniciado sesión, redirigir al login
    header("Location: ../sesion/login.php");
    exit(); // Detiene la ejecución del script
}

$db = new Conexion(); // Crea una instancia de la conexión a la base de datos
$conn = Conexion::$conn; // Obtiene la conexión activa
$id_usuario = $_SESSION['id_usuario']; // Obtiene el ID del usuario de la sesión

// Verificar si se ha enviado el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = trim($_POST['titulo']); // Obtiene y limpia el título de la tarea
    $descripcion = trim($_POST['descripcion']); // Obtiene y limpia la descripción de la tarea

    if (!empty($titulo)) { // Verifica que el título no esté vacío
        // Preparar la consulta para insertar la nueva tarea
        $stmt = $conn->prepare("INSERT INTO tareas (id_usuario, titulo, descripcion) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $id_usuario, $titulo, $descripcion); // Asigna los valores de forma segura
        $stmt->execute(); // Ejecuta la consulta
        $stmt->close(); // Cierra la consulta preparada
    }
}

$db->cerrar(); // Cierra la conexión a la base de datos

// Redirige a la lista de tareas después de agregar una nueva
header("Location: listar.php");
exit(); // Detiene la ejecución del script
