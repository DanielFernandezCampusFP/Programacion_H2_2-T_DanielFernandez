<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
require '../config/conexion.php'; // Incluye el archivo de conexión a la base de datos

// Verificar si el usuario está autenticado
if (!isset($_SESSION['id_usuario'])) { 
    // Si el usuario no ha iniciado sesión, redirigir al login
    header("Location: ../sesion/login.php");
    exit(); // Detiene la ejecución del script
}

$db = new Conexion(); // Crea una instancia de la conexión a la base de datos
$conn = Conexion::$conn; // Obtiene la conexión activa
$id_usuario = $_SESSION['id_usuario']; // Obtiene el ID del usuario autenticado

// Obtener la lista de tareas del usuario, ordenadas por fecha de creación descendente
$stmt = $conn->prepare("SELECT id_tarea, titulo, descripcion, completada, fecha_creacion 
                        FROM tareas 
                        WHERE id_usuario = ? 
                        ORDER BY fecha_creacion DESC");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();

$tareas = []; // Array para almacenar las tareas
while ($fila = $resultado->fetch_assoc()) {
    $tareas[] = $fila; // Almacena cada tarea en el array
}

$stmt->close(); // Cierra la consulta
$db->cerrar(); // Cierra la conexión a la base de datos
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestor de Tareas</title>
    <link rel="stylesheet" href="../ESTILOS/tareas.css"> <!-- Enlace a la hoja de estilos CSS -->
</head>
<body>
    <div class="container">
        <header>
            <h1>Gestor de Tareas de <?= htmlspecialchars($_SESSION['usuario']); ?></h1>
            <nav>
                <a class="btn logout-btn" href="../sesion/logout.php">Cerrar Sesión</a>
                <a class="btn dashboard-btn" href="../sesion/dashboard.php">Volver al Dashboard</a>
            </nav>
        </header>

        <!-- Formulario para agregar nuevas tareas -->
        <section class="task-form">
            <h2>Agregar Nueva Tarea</h2>
            <form method="POST" action="agregar.php">
                <input type="text" name="titulo" placeholder="Título de la tarea" required>
                <textarea name="descripcion" placeholder="Descripción (opcional)"></textarea>
                <button class="btn add-btn" type="submit">Agregar Tarea</button>
            </form>
        </section>

        <!-- Listado de tareas -->
        <section class="task-list">
            <h2>Mis Tareas</h2>

            <?php if (count($tareas) > 0): ?>
                <ul>
                    <?php foreach ($tareas as $tarea): ?>
                        <li class="task-item <?= $tarea['completada'] ? 'completed' : ''; ?>">
                            <div class="task-content">
                                <strong><?= htmlspecialchars($tarea['titulo']); ?></strong>
                                <p><?= nl2br(htmlspecialchars($tarea['descripcion'])); ?></p>
                                <small><?= $tarea['fecha_creacion']; ?></small>
                                <span class="status"><?= $tarea['completada'] ? "Completada" : "Pendiente"; ?></span>
                            </div>
                            <div class="task-actions">
                                <!-- Botón para marcar como completada o pendiente -->
                                <a class="btn complete-btn" href="completar.php?id=<?= $tarea['id_tarea']; ?>">
                                    <?= $tarea['completada'] ? "Marcar como Pendiente" : "Marcar como Completada"; ?>
                                </a>
                                <!-- Botón para eliminar la tarea -->
                                <a class="btn delete-btn" href="eliminar.php?id=<?= $tarea['id_tarea']; ?>"
                                   onclick="return confirm('¿Estás seguro de eliminar esta tarea?');">
                                    Eliminar
                                </a>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="no-tasks">No tienes tareas registradas.</p>
            <?php endif; ?>
        </section>
    </div>
</body>
</html>
