<?php
session_start(); // Inicia la sesión para acceder a las variables de sesión
require '../config/conexion.php'; // Incluye el archivo de conexión a la base de datos

// Verificar si el usuario está autenticado
if (!isset($_SESSION['id_usuario'])) { 
    // Si el usuario no ha iniciado sesión, redirigir al login
    header("Location: ../sesion/login.php");
    exit(); // Detiene la ejecución del script
}

$db = new Conexion(); // Crea una instancia de la conexión a la base de datos
$conn = Conexion::$conn; // Obtiene la conexión activa
$id_usuario = $_SESSION['id_usuario']; // Obtiene el ID del usuario autenticado
$id_tarea = intval($_GET['id']); // Obtiene el ID de la tarea desde la URL y lo convierte en entero

// Consulta SQL para alternar el estado de la tarea (completada o no completada)
$stmt = $conn->prepare("UPDATE tareas SET completada = NOT completada WHERE id_tarea = ? AND id_usuario = ?");
$stmt->bind_param("ii", $id_tarea, $id_usuario); // Asigna valores de forma segura
$stmt->execute(); // Ejecuta la consulta
$stmt->close(); // Cierra la consulta preparada

$db->cerrar(); // Cierra la conexión a la base de datos

// Redirige a la lista de tareas después de actualizar el estado de la tarea
header("Location: listar.php");
exit(); // Detiene la ejecución del script
